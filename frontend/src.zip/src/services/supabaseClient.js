import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || 'https://dbrleoxwcopfdjwfhuqc.supabase.co';
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || 'sb_publishable_G_UrtxiPuwtb_cE-bu9n7g_Lc7dB1E0';

if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
	// Keep this explicit so local setup issues are obvious during development.
	throw new Error('Missing Supabase config. Set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in frontend/.env.');
}

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
